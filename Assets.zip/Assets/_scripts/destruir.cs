using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.InputSystem.iOS;
using UnityEngine.SceneManagement;


public class destruir : MonoBehaviour
{
    public GameObject gameOverText;
    public float delayBeforeRestart = 2f;
   
    void Start()
    {
        
    }

   
    void Update()
    {

    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            // Mostrar mensagem de Game Over
           // if (gameOverText != null)
            {
              //  gameOverText.SetActive(true);
            }

            // Desativar o jogador
            other.gameObject.SetActive(false);

            SceneManager.LoadScene("telaOver");

            // Agendar reinício da cena
           // Invoke("ReiniciarJogo", delayBeforeRestart);
        }
    }

    private void ReiniciarJogo()
    {
        // Recarregar a cena atual
        //SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
    